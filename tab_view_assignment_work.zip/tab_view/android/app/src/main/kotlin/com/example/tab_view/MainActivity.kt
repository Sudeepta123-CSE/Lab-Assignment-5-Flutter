package com.example.tab_view

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
